package main;

public class RiskAnalyzer {

    public static String analyzeRisk(Stock stock) {
        double vol = stock.getVolatility();

        if (vol < 0.2) return "Low Risk";
        else if (vol < 0.5) return "Medium Risk";
        else return "High Risk";
    }
}
