package main;

public class Stock {
    private String symbol;
    private double price;
    private double volatility;

    public Stock(String symbol, double price, double volatility) {
        this.symbol = symbol;
        this.price = price;
        this.volatility = volatility;
    }

    public String getSymbol() { return symbol; }
    public double getPrice() { return price; }
    public double getVolatility() { return volatility; }
}
